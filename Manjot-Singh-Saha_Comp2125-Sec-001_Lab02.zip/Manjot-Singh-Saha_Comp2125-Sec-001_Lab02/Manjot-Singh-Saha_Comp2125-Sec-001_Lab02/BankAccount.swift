//
//  BankAccount.swift
//  Manjot-Singh-Saha_Comp2125-Sec-001_Lab02
//
//  Created by Manjot Singh Saha on 2020-06-23.
//  Copyright © 2020 Manjot Singh Saha. All rights reserved.
//

import Foundation

//Declaring class
open class BankAccount {
    
    //Declaring variables
    open var accountNumber: Int = 0
    open var customerName: String = ""
    
    public var yearlyInterestRate:Double = 0.0 {
        //Declared didSet function
        didSet {
            if yearlyInterestRate <= 0.1 && yearlyInterestRate >= 2.0 {
                print ("Interest Rate is invalid, resetting to \(oldValue)")
            }
        }
    }
    
    public private(set) var accountBalance:Double = 10.00 {
        //Declared didSet function
        didSet {
            if accountBalance < 0.00 {
                print ("Account Balance is invalid, resetting to \(oldValue)")
            }
        }
    }
    
    //Defining constructor without appropriate values
    public init() {
        
    }
    
    //Defining constructor with appropriate values
    public init (accountNumber: Int, customerName: String, yearlyInterestRate: Double, accountBalance: Double) {
        self.accountNumber = accountNumber
        self.customerName = customerName
        
        if yearlyInterestRate >= 0.1 && yearlyInterestRate <= 2.00 {
            self.yearlyInterestRate = yearlyInterestRate
        }
        
        if accountBalance > 0.00 {
            self.accountBalance = accountBalance
        }
    }
    
    // Function Declared for Depositing the money
    public func credit(amount: Double) {
        if accountBalance > 0.0 {
            accountBalance = accountBalance + amount
        }
    }
    
    // Function Declared for withdrawing the money
    public func debit(amount: Double) {
        // if amount is valid, and the balance will not
        // become negative, subtract it from the balance
        if amount > 0.0 {
            if  accountBalance - amount >= 0.0 {
                accountBalance = accountBalance - amount
            }
        }
    }
    
    //Declaring Description
    public var Description: String {
     return String("Customer Name: \(customerName) \nAccount Number: \(accountNumber) \nAccount Balance: \(accountBalance) \nYearly Interest Rate: \(yearlyInterestRate)\n")
     
    }
}
