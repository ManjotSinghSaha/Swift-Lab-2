//
//  BankAccountExtension.swift
//  Manjot-Singh-Saha_Comp2125-Sec-001_Lab02
//
//  Created by Manjot Singh Saha on 2020-06-23.
//  Copyright © 2020 Manjot Singh Saha. All rights reserved.
//

import Foundation

// Declaring another class which is subclass of BankAccount
open class BankAccountExtension : BankAccount {
    
    public convenience init(accountNumber: Int, customerName: String){
        self.init(accountNumber: accountNumber, customerName: customerName)
    }
    
    // Defining Interest function
    public func interest () {
        var interestRate: Double = (accountBalance * ( 1 + yearlyInterestRate)) / 100
    }
}
 
