//
//  main.swift
//  Manjot-Singh-Saha_Comp2125-Sec-001_Lab02
//
//  Created by Manjot Singh Saha on 2020-06-23.
//  Copyright © 2020 Manjot Singh Saha. All rights reserved.
//

import Foundation

func formatAccountString(account: BankAccount) -> String {
    return account.customerName + "'s balance: " + String(account.accountBalance);
}

// create two account objects
let account1 = BankAccount(accountNumber: 983, customerName: "Jon Snow", yearlyInterestRate: 0.5, accountBalance: 50.00)
let account2 = BankAccount(accountNumber: 913, customerName: "Danaerys", yearlyInterestRate: 1.4, accountBalance: -7.53)

print(account1.Description)
print(account2.Description)


print(formatAccountString(account: account1))
print(formatAccountString(account: account2))

// Depositing money to Account 1
var depositAmount = 25.00
print("\nDepositing " + String(depositAmount) + " into account1\n")

account1.credit(amount: depositAmount)
print(formatAccountString(account: account1))
print(formatAccountString(account: account2))

// Depositing money to Account 2
depositAmount = 50
print("\ndepositing " + String(depositAmount)  + " into account2\n")
account2.credit(amount: depositAmount)

print(formatAccountString(account: account1))
print(formatAccountString(account: account2))

//  withdrawing money from Account 1
var withdrawalAmount = 30.00
print("\nWithdrawing " + String(withdrawalAmount) + " from account1\n")
account1.debit(amount: withdrawalAmount)

print(formatAccountString(account: account1))
print(formatAccountString(account: account2))

//  withdrawing money from Account 2
withdrawalAmount = 56.00
print("\nWithdrawing " + String(withdrawalAmount) + " from account2\n")
account2.debit(amount: withdrawalAmount)

print(formatAccountString(account: account1))
print(formatAccountString(account: account2))


